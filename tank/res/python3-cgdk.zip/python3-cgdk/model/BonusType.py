class BonusType:
    MEDIKIT = 0
    REPAIR_KIT = 1
    AMMO_CRATE = 2