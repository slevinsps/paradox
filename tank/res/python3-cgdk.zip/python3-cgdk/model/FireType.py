class FireType:
    NONE = 0
    REGULAR = 1
    PREMIUM = 2
    PREMIUM_PREFERRED = 3