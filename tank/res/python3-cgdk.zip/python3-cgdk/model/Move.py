class Move:
    def __init__(self):
        self.left_track_power = 0.0
        self.right_track_power = 0.0
        self.turret_turn = 0.0
        self.fire_type = None