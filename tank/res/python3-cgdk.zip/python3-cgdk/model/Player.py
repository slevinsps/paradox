class Player:
    def __init__(self, name, score, strategy_crashed):
        self.name = name
        self.score = score
        self.strategy_crashed = strategy_crashed