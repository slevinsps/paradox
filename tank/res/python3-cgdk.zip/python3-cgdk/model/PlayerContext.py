class PlayerContext:
    def __init__(self, tanks, world):
        self.tanks = tanks
        self.world = world