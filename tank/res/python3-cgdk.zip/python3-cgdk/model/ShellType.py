class ShellType:
    REGULAR = 0
    PREMIUM = 1