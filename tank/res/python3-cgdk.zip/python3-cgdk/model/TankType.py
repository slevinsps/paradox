class TankType:
    MEDIUM = 0
    HEAVY = 1
    TANK_DESTROYER = 2